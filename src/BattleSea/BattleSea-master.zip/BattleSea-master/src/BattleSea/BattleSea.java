package BattleSea;
import mvc.*;
public class BattleSea {

    public static void main(String[] args) {
        View view = new View();
        Model model = new Model();
        Controller controller = new Controller(view, model);
        view.setController(controller);
        view.setModel(model);
        view.init();
    }
}
